Pixelpress for Chrome and Edge

1. Extract the ZIP to a permanent folder.
2. Visit chrome://extensions or edge://extensions and enable Developer mode.
3. Choose Load unpacked and select the folder containing manifest.json.
4. Click Pixelpress in the extensions menu to open the offline converter.

Drop images, choose quality and an optional maximum width, then Convert to WebP. After conversion, drag the comparison divider to inspect the original and WebP. Estimated compression loss and file-size savings are shown separately. Use the download icon for one image or Download all for a ZIP. Browser-supported still images are supported; animated inputs export a single frame. For layered graphics, use a PNG export or the Photoshop plugin.
