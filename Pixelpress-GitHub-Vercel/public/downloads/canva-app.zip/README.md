# Canva WebP Export

A desktop Canva editor app for converting selected design pages to WebP. Canva renders the pages as PNG. A small companion running on your computer downloads the selected export and encodes WebP with adjustable quality. Each selected page becomes a separate image.

## Set up once

1. Unzip the package. Install Node.js 22.12 or newer. In a terminal in the folder containing package.json, run the two commands below. Leave the terminal running while exporting.

   ```sh
   npm ci
   npm start
   ```

2. Open [Your apps](https://www.canva.com/developers/apps) in the Canva Developer Portal. Create an app that runs inside Canva and enable the Design Editor intent.
3. Under **Inside Canva → Permissions**, enable **canva:design:content:read**.
4. Under **Inside Canva → Code upload**, select **JavaScript bundle** and upload the included **dist/app.js**. Select **Preview** and open a design.

## Export a design

1. In the app panel, click **Choose design pages**, select pages in Canva’s export dialog, and confirm.
2. Click **Open export** for the page you want. Allow Canva to open the local companion. If the browser restricts opening this address, click **Copy companion link** and paste it into your desktop browser’s address bar.
3. Set quality, click **Convert to WebP**, then **Download WebP**. Repeat for each selected page. PNG transparency is preserved.
4. If the temporary link expires, start a fresh Canva export. If Canva uses a download host the companion does not recognize, click **Download original PNG from Canva**, choose the saved PNG in the companion, and convert. For a PNG you already have, go directly to http://127.0.0.1:38517 while the companion runs.

The app passes a temporary Canva export URL to the companion in your browser. Treat a copied companion link as private. The companion binds only to your computer, fetches supported Canva HTTPS links after you click Convert, and processes files in memory. Each input supports up to 48 MiB and 64 megapixels. Press Ctrl+C in the terminal when finished.

## Rebuild after edits

```sh
npm run build
```

Upload the new dist/app.js in the Developer Portal. The included bundle is already built. The panel uses the Canva Design Editor, design export, and open-external-URL APIs. The companion uses Node.js and sharp.

## Verification

The prebuilt bundle was generated against the declared SDK versions. Local conversion checks confirmed a real WebP with preserved dimensions and alpha. The Canva-hosted preview and its signed export download require a developer account and an actual design. This package is distributed for developer preview. It has no Canva Marketplace listing.

## Canva references

- [Design Editor intent](https://www.canva.dev/docs/apps/intents/design-editor/)
- [Request design export](https://www.canva.dev/docs/apps/api/latest/design-request-export/)
- [Open an external URL](https://www.canva.dev/docs/apps/api/latest/platform-request-open-external-url/)
- [Upload a JavaScript bundle](https://www.canva.dev/docs/apps/bundling-apps/)
