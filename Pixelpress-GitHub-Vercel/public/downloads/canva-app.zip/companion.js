const get = id => document.getElementById(id);
const data = new URLSearchParams(location.hash.slice(1));
history.replaceState(null,"",location.pathname);
let source = data.get("source") || "";
try { if (new URL(source).protocol !== "https:") source = ""; } catch { source = ""; }
const designName = data.get("name") || "Canva design";
let objectUrl;
if (source) {get("original").href=source; get("original").hidden=false; get("title").textContent=designName;}
function reset() {
  if (objectUrl) URL.revokeObjectURL(objectUrl);
  objectUrl = null;
  get("download").hidden=true; get("status").textContent="";
  get("value").textContent=get("quality").value+"%";
  get("convert").disabled=!source && !get("file").files.length;
}
get("file").onchange=reset; get("quality").oninput=reset; reset();
get("convert").onclick=async () => {
  reset();
  for (const id of ["convert","quality","file"]) get(id).disabled=true;
  get("status").textContent="Converting…";
  try {
    const local=get("file").files[0];
    const response=await fetch("/convert",{method:"POST",headers:{"Content-Type":local?"image/png":"application/json","X-WebP-Quality":get("quality").value},body:local || JSON.stringify({source})});
    if (!response.ok) throw Error(await response.text() || "Unable to convert.");
    const blob=await response.blob();
    objectUrl=URL.createObjectURL(blob); const link=get("download"); link.href=objectUrl;
    const base=(local?local.name.replace(/\.png$/i,""):designName).replace(/[^\p{L}\p{N}\s_.-]/gu,"_").slice(0,140).trim() || "Canva design";
    link.download=base+".webp"; link.hidden=false; get("status").textContent="WebP ready · "+Math.ceil(blob.size/1024)+" KB";
  } catch (error) {get("status").textContent=error.message;}
  finally {for (const id of ["convert","quality","file"]) get(id).disabled=false;}
};
