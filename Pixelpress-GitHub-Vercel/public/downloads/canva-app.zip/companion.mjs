import http from "node:http";
import {readFile} from "node:fs/promises";
import sharp from "sharp";

const port = 38517;
const origin = "http://127.0.0.1:" + port;
const maxBytes = 48 * 1024 * 1024;
const png = Buffer.from([137,80,78,71,13,10,26,10]);
const assets = new Map([
  ["/", ["text/html; charset=utf-8", await readFile(new URL("companion.html", import.meta.url))]],
  ["/companion.js", ["text/javascript; charset=utf-8", await readFile(new URL("companion.js", import.meta.url))]]
]);
async function limitedBytes(stream, max) {
  const chunks = [];
  let size = 0;
  for await (const value of stream) {
    size += value.length;
    if (size > max) throw Error("File is too large.");
    chunks.push(value);
  }
  return Buffer.concat(chunks);
}
function canvaAddress(address) {
  const url = new URL(address);
  if (url.protocol !== "https:" || url.username || url.password || url.port ||
      !(url.hostname === "canva.com" || url.hostname.endsWith(".canva.com"))) {
    throw Error("Use the PNG file option for this export address.");
  }
  return url;
}
async function fetchPng(source) {
  let url = canvaAddress(source);
  const signal = AbortSignal.timeout(30000);
  for (let hop=0; hop<4; hop++) {
    const response = await fetch(url, {redirect:"manual",signal});
    if ([301,302,303,307,308].includes(response.status)) {
      await response.body?.cancel();
      const location = response.headers.get("location");
      if (!location) throw Error("Missing redirect.");
      url = canvaAddress(new URL(location,url));
      continue;
    }
    if (!response.ok || !response.body) { await response.body?.cancel(); throw Error("Could not download the export."); }
    if (Number(response.headers.get("content-length")) > maxBytes) { await response.body.cancel(); throw Error("File is too large."); }
    return limitedBytes(response.body, maxBytes);
  }
  throw Error("Too many redirects.");
}
let active = false;
http.createServer(async (req,res) => {
  res.setHeader("Cache-Control","no-store");
  res.setHeader("X-Content-Type-Options","nosniff");
  res.setHeader("Referrer-Policy","no-referrer");
  res.setHeader("Content-Security-Policy","default-src 'none'; script-src 'self'; style-src 'unsafe-inline'; connect-src 'self'; img-src blob:; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
  if (req.headers.host !== "127.0.0.1:"+port) {res.writeHead(403).end(); return;}
  if (req.method === "GET" && assets.has(req.url)) {
    const [type, data] = assets.get(req.url);
    res.writeHead(200,{"Content-Type":type}).end(data); return;
  }
  if (req.method !== "POST" || req.url !== "/convert") { res.writeHead(404).end(); return; }
  if (req.headers.origin !== origin) {res.writeHead(403).end(); return;}
  if (active) {res.writeHead(429).end("Wait for the current export."); return;}
  active = true;
  try {
    const quality = Number(req.headers["x-webp-quality"]);
    if (!Number.isInteger(quality) || quality<1 || quality>100) throw Error("Invalid quality.");
    const type = req.headers["content-type"];
    let input;
    if (type === "application/json") {
      const data = JSON.parse((await limitedBytes(req, 24000)).toString("utf8"));
      input = await fetchPng(data.source);
    } else if (type === "image/png") {
      input = await limitedBytes(req, maxBytes);
    } else { throw Error("PNG input is required."); }
    if (!input.subarray(0,8).equals(png)) throw Error("PNG input is required.");
    const output = await sharp(input,{limitInputPixels:64_000_000}).webp({quality}).toBuffer();
    res.writeHead(200,{"Content-Type":"image/webp"}).end(output);
  } catch {
    res.writeHead(400,{"Content-Type":"text/plain"}).end("Could not convert this export. Download the original PNG and choose it below. Use up to 48 MB and 64 megapixels per file.");
  } finally { active = false; }
}).listen(port,"127.0.0.1",()=>console.log("WebP companion running at "+origin+". Close with Ctrl+C."));
