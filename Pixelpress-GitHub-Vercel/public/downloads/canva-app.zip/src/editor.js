import { prepareDesignEditor } from "@canva/intents/design";
import { requestExport } from "@canva/design";
import { requestOpenExternalUrl } from "@canva/platform";

function button(label, click) {
  const control = document.createElement("button");
  control.textContent = label;
  control.style.cssText = "border:1px solid #b8ade4;border-radius:8px;padding:10px;font:inherit;font-weight:600;cursor:pointer";
  control.onclick = click;
  return control;
}

prepareDesignEditor({ async render() {
  const root = document.getElementById("root");
  root.replaceChildren();
  root.style.cssText = "display:grid;gap:12px;padding:16px;font:14px/1.5 system-ui";
  const title = document.createElement("h2");
  title.style.margin = "0";
  title.textContent = "WebP export";
  const intro = document.createElement("div");
  intro.textContent = "Choose design pages in Canva, then save a WebP for each page with the desktop companion.";
  const message = document.createElement("div");
  message.setAttribute("role", "status");
  const pages = document.createElement("div");
  pages.style.cssText = "display:grid;gap:8px";
  const select = button("Choose design pages", async () => {
    select.disabled = true;
    pages.replaceChildren();
    message.textContent = "Waiting for Canva…";
    try {
      const result = await requestExport({acceptedFileTypes:[{type:"png",zipped:"never"}]});
      if (result.status !== "completed") { message.textContent = "Export canceled."; return; }
      message.textContent = "Open a page in the desktop companion. Keep npm start running on this computer.";
      result.exportBlobs.forEach(({url}, i) => {
        const params = new URLSearchParams({source:url,name:(result.title || "Canva design") + (result.exportBlobs.length > 1 ? "-" + (i+1) : "")});
        const local = "http://127.0.0.1:38517/#" + params;
        const row = document.createElement("section");
        row.style.cssText = "display:flex;flex-wrap:wrap;gap:6px";
        row.append(button("Open export " + (i+1), async () => {
          try {
            const opened = await requestOpenExternalUrl({url:local});
            if (opened.status === "aborted") message.textContent = "Opening was canceled. You can copy the companion link and paste it into your desktop browser.";
          } catch { message.textContent = "Copy the companion link and paste it into your desktop browser."; }
        }), button("Copy companion link", async () => {
          try { await navigator.clipboard.writeText(local); message.textContent = "Copied. Paste into your desktop browser. The link contains your temporary Canva export."; }
          catch {
            const field = document.createElement("textarea");
            field.readOnly = true; field.value = local; field.setAttribute("aria-label","Temporary local companion link");
            row.append(field); field.select();
          }
        }));
        pages.append(row);
      });
    } catch { message.textContent = "Canva could not export these pages. Check the app’s design content read permission and try again."; }
    finally { select.disabled = false; }
  });
  root.append(title,intro,select,message,pages);
} });
