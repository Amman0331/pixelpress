# WebP Export for Photoshop

A local Photoshop desktop panel that saves a WebP copy of your open image. Choose a quality from 0 to 100 for lossy compression, or enable lossless compression. Exports omit EXIF, XMP, and Photoshop extras.

## Load the panel

1. Extract this ZIP to a permanent folder on your computer.
2. Open Photoshop desktop 23.3 or newer. In Creative Cloud Desktop, install and launch **UXP Developer Tools**.
3. Enable Developer Mode when UXP Developer Tools prompts you. If Photoshop offers a Developer Mode setting, enable it and restart Photoshop.
4. In UXP Developer Tools, choose **Add Plugin** and select the extracted **manifest.json**. Open the plugin's actions menu and choose **Load**.
5. In Photoshop, open **Plugins → WebP Export**. You can reopen the panel from the Plugins menu. If it disappears after restarting Photoshop, click **Load** again in UXP Developer Tools.

## Export your artwork

Open an 8-bit RGB document, choose the export quality and click **Save WebP copy**. Choose the destination and save. The panel exports the visible composition at its current dimensions, including transparency. For CMYK print artwork or a 16-bit master, use **Image → Duplicate** and change the duplicate to **RGB Color** and **8 Bits/Channel** under **Image → Mode** before exporting. Use a separate filename to keep your master.

This ZIP contains the local development plugin. You can use it via UXP Developer Tools. Adobe Marketplace distribution requires registering a plugin ID and packaging it through Adobe's tools.

## Adobe references

- [Native WebP in Photoshop](https://helpx.adobe.com/photoshop/kb/support-webp-image-format.html)
- [Loading a local plugin](https://developer.adobe.com/photoshop/uxp/2022/guides/devtool/udt-walkthrough/)
