const { app, action, core, constants } = require("photoshop");
const { localFileSystem } = require("uxp").storage;

const qualityControl = document.getElementById("quality");
const losslessControl = document.getElementById("lossless");
const saveButton = document.getElementById("save");
const status = document.getElementById("status");

losslessControl.addEventListener("change", () => {
  qualityControl.disabled = losslessControl.checked;
});

saveButton.addEventListener("click", async () => {
  if (saveButton.disabled) return;
  saveButton.disabled = true;
  status.textContent = "";
  try {
    if (!app.documents.length) throw new Error("Open a document in Photoshop first.");
    const source = app.activeDocument;
    if (source.mode !== constants.DocumentMode.RGB ||
        source.bitsPerChannel !== constants.BitsPerChannelType.EIGHT) {
      throw new Error("Duplicate the document and choose Image > Mode > RGB Color and 8 Bits/Channel on the duplicate.");
    }
    const documentId = source.id;
    const base = source.name.replace(/\.[^.]+$/, "") || "image";
    const file = await localFileSystem.getFileForSaving(base + "-web.webp", { types: ["webp"] });
    if (!file) {
      status.textContent = "Export canceled.";
      return;
    }
    if (!/\.webp$/i.test(file.name)) throw new Error("Choose a filename ending in .webp.");

    const format = {
      _obj: "WebPFormat",
      compression: {
        _enum: "WebPCompression",
        _value: losslessControl.checked ? "compressionLossless" : "compressionLossy"
      },
      includeXMPData: false,
      includeEXIFData: false,
      includePsExtras: false
    };
    if (!losslessControl.checked) format.quality = Math.round(Number(qualityControl.value));
    const path = localFileSystem.createSessionToken(file);
    await core.executeAsModal(async () => {
      if (!app.documents.length || app.activeDocument.id !== documentId) {
        throw new Error("The active document changed. Select your image and export again.");
      }
      const [result] = await action.batchPlay([{
        _obj: "save",
        as: format,
        in: { _path: path, _kind: "local" },
        documentID: documentId,
        copy: true,
        lowerCase: true,
        _options: { dialogOptions: "dontDisplay" }
      }], {});
      if (result._obj === "error") throw new Error(result.message || "Photoshop could not save the WebP.");
    }, { commandName: "Save WebP copy" });
    status.textContent = "Saved " + file.name;
  } catch (error) {
    status.textContent = error.message || "Photoshop could not complete the export.";
  } finally {
    saveButton.disabled = false;
  }
});
